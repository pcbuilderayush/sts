import { Component, OnInit } from '@angular/core';
import { EmpService } from '../service/emp.service';
import { Emp } from '../model/emp';

@Component({
  selector: 'app-emp-list',
  templateUrl: './emp-list.component.html',
  styleUrls: ['./emp-list.component.css']
})
export class EmpListComponent implements OnInit {

  emps:Emp[];
  errMsg:string;

  constructor(private empService: EmpService) { }

  ngOnInit() {
      this.emps=null;
      this.errMsg=null;

    this.empService.getAll().subscribe(
      (data) =>{this.emps=data;},
      (err)=>{this.errMsg="Sorry! Server is not reachable";}

    );
  }

delete(empId:number){
  if(confirm(`Are You Sure Of deleting emp#${empId}`)){
    this.empService.deleteById(empId).subscribe(
      ()=>{this.loadData();},
      (err)=>{this.errMsg=err;}
    )
  }
}
  loadData() {
    throw new Error("Method not implemented.");
  }


}
