export class Emp {
    public empId:number;
    public firstName:string;
    public lastName:string;
    public basic:number;
    public joinDate:Date;
    public dept:string;
    public mobileNumber:string;
    public email:string;
}
