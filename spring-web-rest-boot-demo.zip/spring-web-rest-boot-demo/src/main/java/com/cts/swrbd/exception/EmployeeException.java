package com.cts.swrbd.exception;

@SuppressWarnings("serial")
public class EmployeeException extends Exception {
	public EmployeeException(String errorMessage) {
		super(errorMessage);
	}
}
