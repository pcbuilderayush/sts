package com.example.demo;

import static org.assertj.core.api.Assertions.assertThat;

import java.time.LocalDate;

import org.junit.After;
import org.junit.Before;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringBootConfiguration;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import com.cts.swrbd.dao.EmployeeRepository;
import com.cts.swrbd.model.Department;
import com.cts.swrbd.model.Employee;
import com.cts.swrbd.service.EmployeeService;
import com.cts.swrbd.service.EmployeeServiceImpl;

@RunWith(SpringRunner.class)
@DataJpaTest
public class EmployeeDAOUnitTest {
	@SpringBootConfiguration
	@ContextConfiguration
	@TestConfiguration
	static class EmployeeServiceImplTestContextConfiguration {
		@Bean
		public EmployeeService employeeService() {
			return new EmployeeServiceImpl();
		}
	}
	
	@Autowired
	private EmployeeService employeeService;
	
	private Employee emps[];
	
	@Autowired
	private TestEntityManager entityManager;
	
	@Autowired
	private EmployeeRepository employeeRepository;
	
	public EmployeeDAOUnitTest() {
		emps= new Employee[] {
				new Employee("Ayush","Pratap",45000,LocalDate.now(),Department.DEVELOPMENT,"9045110022","ayush@da.d")
			
				
		};
	}
	
	
	@Before
	public void voidsetUp() {
		Employee emp= new Employee("Ayush", "Pratap", 45000, LocalDate.now(), Department.DEVELOPMENT, "9411203032", "aussf@as.d");
		Mockito.when(employeeRepository.findByMobileNumber(emp.getMobileNumber())).thenReturn(emp);
	}
	
	
	@Test
	public void whenValidMobileNumber_thenEmployeeShouldBeFound() {
		String mno="9411203032";
		Employee found=employeeService.findByMobileNumber(mno);
		assertThat(found.getMobileNumber()).isEqualTo(mno);
	}
	
	@Test
	public void whenInValidMobileNumber_thenEmployeeShouldNotBeFound() {
		String mno="6562652363";
		Employee found =employeeService.findByMobileNumber(mno);
		assertThat(found).isNull();
	}
	
	@Before
	public void beforeEachTest() {
		for(Employee e:emps) {
			entityManager.persist(e);
		}
		entityManager.flush();
	}
	@After
	public void afterEachTest() {
		for(Employee e:emps) {
			entityManager.remove(e);
		}
		entityManager.flush();
	}
	@Test
	public void whenFindByMobileNumber_thenReturnEmployee() {
		Employee e=employeeRepository.findByMobileNumber(emps[0].getMobileNumber());
		assertThat(e).isEqualTo(emps[0]);
	}
	@Test
	public void whenFindByMobileNumber_withNonExistingMobileNumber_thenReturnNull() {
		Employee e= employeeRepository.findByMobileNumber("9411250502");
		assertThat(e).isNull();
	}
}
