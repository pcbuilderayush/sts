package com.example.demo;

import static org.hamcrest.CoreMatchers.is;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.jsonPath;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.time.LocalDate;
import org.mockito.BDDMockito.*;

import org.assertj.core.util.Arrays;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

import com.cts.swrbd.controller.EmployeeAPI;
import com.cts.swrbd.model.Department;
import com.cts.swrbd.model.Employee;
import com.cts.swrbd.service.EmployeeService;

import antlr.collections.List;

@RunWith(SpringRunner.class)
@WebMvcTest(EmployeeAPI.class)

public class EmployeeAPIUnitTest {

	@Autowired
	private MockMvc mvc;
	@MockBean
	private EmployeeService service;
	
	@Test
	public Void whenFindAll_thenReturnJsonArray() throws Exception{
		Employee emp= new Employee("Ayush", "Pratap", 60000, LocalDate.now(), Department.DEVELOPMENT, "6552152020", "ahsn@sc.s");
		
		List<Employee> allEmployees = Arrays.asList(emp);

		given(service.findAll()).willReturn(allEmployees);
		
		mvc.perform(get("/emps").contentType(MediaType.APPLICATION_JSON))
		.andExpect(status().isOk())
		.andExpect(jsonPath("$",hasSize(1)))
		.andExpect(jsonPath("$[0].mobileNumber",is(emp.getMobileNumber())));
	}
}
