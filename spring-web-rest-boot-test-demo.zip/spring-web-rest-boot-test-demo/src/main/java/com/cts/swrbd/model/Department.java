package com.cts.swrbd.model;

public enum Department {
	SALES,OPERATIONS,DELIVERY,DEVELOPMENT,MARKETING;
}
